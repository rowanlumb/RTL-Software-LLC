define( function() {
	"use strict";

	return window.document;
} );
