#!/usr/bin/env python
# coding: utf-8

# In[13]:


from pandas import read_table, DataFrame
df = read_table("C:\\Users\\rtlum\\Documents\\DataSci_Projects\\PythonTensorFlowProjects\\Acoustic_Emission\\dataset.txt",header='infer',sep='\s')
df2 = read_table("C:\\Users\\rtlum\\Documents\\DataSci_Projects\\PythonTensorFlowProjects\\Acoustic_Emission\\segmentData_basic.txt",header='infer',sep='\s')


# In[14]:


import tensorflow as tf
import numpy as np

from tensorflow.keras import datasets, layers, models, utils, callbacks
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
import tensorflow_docs as tfdocs
import tensorflow_docs.plots
import tensorflow_docs.modeling
from scipy import stats


# In[15]:


def get_sec(time_str):
    for x in time_str:
        """Get Seconds from time."""
        x = x.replace('"', '')
        h, m, s = x.split(':')
        time = float(h) * 3600 + float(m) * 60 + float(s)
        if 'time_array' in locals():
            time_array = [time];
        else:
            time_array.append(time)
        
    return time_array


# In[ ]:





# In[16]:


train_dataset = df.sample(frac=0.8,random_state=0)
test_dataset = df.drop(train_dataset.index)

train_stats = train_dataset.describe()
train_stats = train_stats.transpose()
train_stats


# In[17]:


def norm(x):
  return (x - train_stats['min']) / (train_stats['max']-train_stats['min'])
train_dataset = norm(train_dataset)
test_dataset = norm(test_dataset)

label_list = ['XT','Spec','ramp','X']
train_labels = train_dataset.pop('XT')
train_dataset.pop(label_list[1])
train_dataset.pop(label_list[2])
train_dataset.pop(label_list[3])

test_labels = test_dataset.pop(label_list[0])
test_dataset.pop(label_list[1])
test_dataset.pop(label_list[2])
test_dataset.pop(label_list[3])

normed_train_data = train_dataset
normed_test_data = test_dataset


# In[18]:


def build_model():
  model = tf.keras.Sequential([
    tf.keras.layers.Dense(64, activation='relu', input_shape=[len(train_dataset.keys())]),
    tf.keras.layers.Dense(64, activation='relu'),
    tf.keras.layers.Dense(1)
  ])

  optimizer = tf.keras.optimizers.RMSprop(0.001)

  model.compile(loss='mse',
                optimizer=optimizer,
                metrics=['mae', 'mse'])
  return model

model = build_model()
normed_train_data


# In[34]:


tf.keras.utils.plot_model(model, to_file='model_plot.png', show_shapes=True, show_layer_names=True)


# In[20]:



EPOCHS = 1000
history = model.fit(
  normed_train_data, train_labels,
  epochs=EPOCHS, validation_split = 0.2, verbose=0,
  callbacks=[tfdocs.modeling.EpochDots()])


# In[21]:


hist = pd.DataFrame(history.history)
hist['epoch'] = history.epoch
hist.tail()


# In[22]:


plotter = tfdocs.plots.HistoryPlotter(smoothing_std=2)


# In[28]:


plotter.plot({'Basic': history}, metric = "mae")
plt.ylim([0, .2])
plt.ylabel('MAE [Load Cycles Until Failure]')
plt.savefig('MAE.png')


# In[31]:


test_predictions = model.predict(normed_test_data).flatten()

a = plt.axes(aspect='equal')
plt.scatter(test_labels, test_predictions)
plt.xlabel('True Values [Load Cycles Until Failure]')
plt.ylabel('Predictions [Load Cycles Until Failure]')
lims = [0, 1.5]
plt.xlim(lims)
plt.ylim(lims)
_ = plt.plot(lims, lims)
plt.savefig('Scatter.png')


# In[32]:


error = test_predictions - test_labels
plt.hist(error, bins = 25)
plt.xlabel("Prediction Error [Load Cycles Until Failure]")
_ = plt.ylabel("Count")
plt.savefig('Pred_Error.png')

