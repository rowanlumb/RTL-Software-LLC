from pandas import read_table, DataFrame
from scipy import stats
from pandas import read_table, DataFrame
from scipy import stats
import matplotlib
import matplotlib.pyplot as plt
import numpy as np


df = read_table("C:\\Users\\rtlum\\Documents\\DataSci_Projects\\PythonTensorFlowProjects\\Acoustic_Emission\\dataset.txt",header='infer',sep='\s')
col_names = df.columns.values
col_names = col_names.tolist()



harvest = stats.spearmanr(df)
harvest = np.around(harvest,3)

fig, ax = plt.subplots()
im = ax.imshow(harvest[0],cmap='hot')

# We want to show all ticks...
ax.set_xticks(np.arange(len(col_names)))
ax.set_yticks(np.arange(len(col_names)))
# ... and label them with the respective list entries
ax.set_xticklabels(col_names)
ax.set_yticklabels(col_names)

# Rotate the tick labels and set their alignment.
plt.setp(ax.get_xticklabels(), rotation=45, ha="right",
         rotation_mode="anchor")

# Loop over data dimensions and create text annotations.
for i in range(len(col_names)):
    for j in range(len(col_names)):
        text = ax.text(j, i, harvest[0][i, j],
                       ha="center", va="center", color="w")

ax.set_title("Spearman Rank Cooefficient between Variables")
fig.tight_layout()
plt.savefig('Spearman.png')
plt.show()