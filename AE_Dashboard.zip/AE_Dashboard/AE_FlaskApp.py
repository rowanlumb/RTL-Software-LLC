from flask import Flask, render_template, request, redirect, url_for, send_from_directory
from werkzeug.utils import secure_filename
import tensorflow as tf
from tensorflow.keras import datasets, layers, models
import os
from PIL import Image
import numpy as np
import logging
import simplejson as json
import scipy.stats as st

app = Flask('Acoustic Emission Data Dashboard')
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'}




def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route('/favicon.ico')
def fav():
    return send_from_directory(os.path.join(app.root_path, 'static'),'favicon.ico')

@app.route('/', methods=['GET'])
def upload_file():
    app.logger.info("Here's some info")
    if request.method == 'GET':
        return render_template('dashboard_main.html')




app.run("localhost", "9999", debug=True)
