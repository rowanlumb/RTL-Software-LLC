df_auto_seg <- function(df,q){
for(i in 1:length(unlist(df[,"PA0"]))){
if(df[i,"PA0"] >4000){
assign(paste("df_",q,sep=""),df[1:i,], envir = .GlobalEnv)
break;
}}
}
###################################Nov12_1 Test Data Proccessing 
########################Change the file paths (9 total) and run in R. You might need to install some libraries, but it should be straight forward. 
########################
library(data.table)
library(NLP)


df <- fread("C:\\Users\\rtlum\\Documents\\Thesis\\Thesis_Fatigue\\Data_Analysis\\HighStress_LowCycle\\high_stress_nov12.txt",sep="auto",nrows=Inf, fill=TRUE)
specimen = 1;

q <- 1;
r <- 4;
flag <- 0;
df <- subset(df, df$PA0 < 4200 & df$PA0 > 100);
X <- c(1:length(unlist(df[,"PA0"])))
XT <- as.double(c(1:length(unlist(df[,"PA0"]))))
df <- cbind(df,X);
df <- cbind(df,XT);
for(i in 4:length(unlist(df[,"PA0"]))){
x <- df[i,"PA0"]- df[i-3,"PA0"];
r <- r+1;
flag <- flag +1;
if(!is.na(unlist(x))){
if(abs(unlist(x)) > 3000 & q == 1){
flag <- 0;
df[1:r,"X"] <- (q-1)*8000;
df[1:r,"XT"] <- (10*8000)-((q-1)*8000)
#df[1:r,"XT"] <- (q-1)/10;
assign(paste("df_",q,sep=""),df[1:r,]);
df_auto_seg(eval(as.symbol(paste("df_",q,sep=""))),q);
q <- q+1;
print("Once");}
else if (q > 1 & flag > 30 & abs(unlist(x)) > 3000){
h <- r - flag;
df[h:r,"X"] <- (q-1)*8000;
df[h:r,"XT"] <- (10*8000)-((q-1)*8000);
#df[h:r,"XT"] <- (q-1)/10;
assign(paste("df_",q,sep=""),df[h:r,]);
df_auto_seg(eval(as.symbol(paste("df_",q,sep=""))),q);
q <- q+1;
flag <- 0;
}
}}

q <- q-1
df_10 <- df_10[4:length(unlist(df_10[,"PA0"])),]

#############################Concate into NN input

for (z in 1:q){
df_x <- eval(as.symbol(paste("df_",z,sep="")))
for (i in 11:length(unlist(df_x[,"PA0"]))){
if(i == 11 & z == 1){
trainData <- cbind(Spec=specimen,ramp=z,df_x[i,"X"],df_x[i,"XT"],O=i-10,df_x[i,"E(SS)"],df_x[i,"RMS"],df_x[i-1,"PA0"],df_x[i-1,"E(SS)"],df_x[i-1,"RMS"],df_x[i-2,"PA0"],df_x[i-2,"E(SS)"],df_x[i-2,"RMS"],df_x[i-3,"PA0"],df_x[i-3,"E(SS)"],df_x[i-3,"RMS"],df_x[i-4,"PA0"],df_x[i-4,"E(SS)"],df_x[i-4,"RMS"],df_x[i-5,"PA0"],df_x[i-5,"E(SS)"],df_x[i-5,"RMS"],df_x[i-6,"PA0"],df_x[i-6,"E(SS)"],df_x[i-6,"RMS"],df_x[i-7,"PA0"],df_x[i-7,"E(SS)"],df_x[i-7,"RMS"],df_x[i-8,"PA0"],df_x[i-8,"E(SS)"],df_x[i-8,"RMS"],df_x[i-9,"PA0"],df_x[i-9,"E(SS)"],df_x[i-9,"RMS"],df_x[i-10,"PA0"],df_x[i-10,"E(SS)"],df_x[i-10,"RMS"])
}else{
new_datapoint <- NULL
new_datapoint <- cbind(Spec=specimen,ramp=z,df_x[i,"X"],df_x[i,"XT"],O=i-10,df_x[i,"E(SS)"],df_x[i,"RMS"],df_x[i-1,"PA0"],df_x[i-1,"E(SS)"],df_x[i-1,"RMS"],df_x[i-2,"PA0"],df_x[i-2,"E(SS)"],df_x[i-2,"RMS"],df_x[i-3,"PA0"],df_x[i-3,"E(SS)"],df_x[i-3,"RMS"],df_x[i-4,"PA0"],df_x[i-4,"E(SS)"],df_x[i-4,"RMS"],df_x[i-5,"PA0"],df_x[i-5,"E(SS)"],df_x[i-5,"RMS"],df_x[i-6,"PA0"],df_x[i-6,"E(SS)"],df_x[i-6,"RMS"],df_x[i-7,"PA0"],df_x[i-7,"E(SS)"],df_x[i-7,"RMS"],df_x[i-8,"PA0"],df_x[i-8,"E(SS)"],df_x[i-8,"RMS"],df_x[i-9,"PA0"],df_x[i-9,"E(SS)"],df_x[i-9,"RMS"],df_x[i-10,"PA0"],df_x[i-10,"E(SS)"],df_x[i-10,"RMS"])
trainData <- rbind(trainData, new_datapoint)
}
}}

################Clean Workspace
rm(df_1,df_2,df_3,df_4,df_5,df_6,df_7,df_8,df_9,df_10,df);
rm(x,X,XT,i,h,r,flag,q,z,new_datapoint,df_x)


########################################################################

#####################

#####################

########################################################################Nov12_2 Test Data Proccessing 
df <- fread("C:\\Users\\rtlumb\\Documents\\Thesis_Fatigue\\Data_Analysis\\HighStress_LowCycle\\high_stress_nov12_2.txt",sep="auto",nrows=Inf, fill=TRUE)
specimen = 2;

q <- 1;
r <- 4;
flag <- 0;
df <- subset(df, df$PA0 < 4200 & df$PA0 > 100);
X <- c(1:length(unlist(df[,"PA0"])))
XT <- as.double(c(1:length(unlist(df[,"PA0"]))))
df <- cbind(df,X);
df <- cbind(df,XT);
for(i in 4:length(unlist(df[,"PA0"]))){
x <- df[i,"PA0"]- df[i-3,"PA0"];
r <- r+1;
flag <- flag +1;
if(!is.na(unlist(x))){
if(abs(unlist(x)) > 3000 & q == 1){
flag <- 0;
df[1:r,"X"] <- (q-1)*8000;
df[1:r,"XT"] <- (9*8000)-((q-1)*8000)
#df[1:r,"XT"] <- (q-1)/9;
assign(paste("df_",q,sep=""),df[1:r,]);
df_auto_seg(eval(as.symbol(paste("df_",q,sep=""))),q);
q <- q+1;
print("Once");}
else if (q > 1 & flag > 30 & abs(unlist(x)) > 2500){
h <- r - flag;
df[h:r,"X"] <- (q-1)*8000;
df[h:r,"XT"] <- (9*8000)-((q-1)*8000)
#df[h:r,"XT"] <- (q-1)/9;
assign(paste("df_",q,sep=""),df[h:r,]);
df_auto_seg(eval(as.symbol(paste("df_",q,sep=""))),q);
q <- q+1;
flag <- 0;
}
}}
q <- q-1

#############################Concate into NN input

for (z in 1:q){
df_x <- eval(as.symbol(paste("df_",z,sep="")))
for (i in 11:length(unlist(df_x[,"PA0"]))){
new_datapoint <- NULL
new_datapoint <- cbind(Spec=specimen,ramp=z,df_x[i,"X"],df_x[i,"XT"],O=i-10,df_x[i,"E(SS)"],df_x[i,"RMS"],df_x[i-1,"PA0"],df_x[i-1,"E(SS)"],df_x[i-1,"RMS"],df_x[i-2,"PA0"],df_x[i-2,"E(SS)"],df_x[i-2,"RMS"],df_x[i-3,"PA0"],df_x[i-3,"E(SS)"],df_x[i-3,"RMS"],df_x[i-4,"PA0"],df_x[i-4,"E(SS)"],df_x[i-4,"RMS"],df_x[i-5,"PA0"],df_x[i-5,"E(SS)"],df_x[i-5,"RMS"],df_x[i-6,"PA0"],df_x[i-6,"E(SS)"],df_x[i-6,"RMS"],df_x[i-7,"PA0"],df_x[i-7,"E(SS)"],df_x[i-7,"RMS"],df_x[i-8,"PA0"],df_x[i-8,"E(SS)"],df_x[i-8,"RMS"],df_x[i-9,"PA0"],df_x[i-9,"E(SS)"],df_x[i-9,"RMS"],df_x[i-10,"PA0"],df_x[i-10,"E(SS)"],df_x[i-10,"RMS"])
trainData <- rbind(trainData, new_datapoint)
}}


for (z in 1:q){
df_x <- eval(as.symbol(paste("df_",z,sep="")))
for (i in 11:length(unlist(df_x[,"PA0"]))){
if(i == 11 & z == 1){
data <- cbind(Spec=specimen,ramp=z,df_x[i,"X"],df_x[i,"XT"],O=i-10,df_x[i,"E(SS)"],df_x[i,"RMS"],df_x[i-1,"PA0"],df_x[i-1,"E(SS)"],df_x[i-1,"RMS"],df_x[i-2,"PA0"],df_x[i-2,"E(SS)"],df_x[i-2,"RMS"],df_x[i-3,"PA0"],df_x[i-3,"E(SS)"],df_x[i-3,"RMS"],df_x[i-4,"PA0"],df_x[i-4,"E(SS)"],df_x[i-4,"RMS"],df_x[i-5,"PA0"],df_x[i-5,"E(SS)"],df_x[i-5,"RMS"],df_x[i-6,"PA0"],df_x[i-6,"E(SS)"],df_x[i-6,"RMS"],df_x[i-7,"PA0"],df_x[i-7,"E(SS)"],df_x[i-7,"RMS"],df_x[i-8,"PA0"],df_x[i-8,"E(SS)"],df_x[i-8,"RMS"],df_x[i-9,"PA0"],df_x[i-9,"E(SS)"],df_x[i-9,"RMS"],df_x[i-10,"PA0"],df_x[i-10,"E(SS)"],df_x[i-10,"RMS"])
}else{
new_datapoint <- NULL
new_datapoint <- cbind(Spec=specimen,ramp=z,df_x[i,"X"],df_x[i,"XT"],O=i-10,df_x[i,"E(SS)"],df_x[i,"RMS"],df_x[i-1,"PA0"],df_x[i-1,"E(SS)"],df_x[i-1,"RMS"],df_x[i-2,"PA0"],df_x[i-2,"E(SS)"],df_x[i-2,"RMS"],df_x[i-3,"PA0"],df_x[i-3,"E(SS)"],df_x[i-3,"RMS"],df_x[i-4,"PA0"],df_x[i-4,"E(SS)"],df_x[i-4,"RMS"],df_x[i-5,"PA0"],df_x[i-5,"E(SS)"],df_x[i-5,"RMS"],df_x[i-6,"PA0"],df_x[i-6,"E(SS)"],df_x[i-6,"RMS"],df_x[i-7,"PA0"],df_x[i-7,"E(SS)"],df_x[i-7,"RMS"],df_x[i-8,"PA0"],df_x[i-8,"E(SS)"],df_x[i-8,"RMS"],df_x[i-9,"PA0"],df_x[i-9,"E(SS)"],df_x[i-9,"RMS"],df_x[i-10,"PA0"],df_x[i-10,"E(SS)"],df_x[i-10,"RMS"])
data <- rbind(data, new_datapoint)
}
}}
trainData <- rbind(trainData,data)

################Clean Workspace
rm(df_1,df_2,df_3,df_4,df_5,df_6,df_7,df_8,df_9,df,data)
rm(x,X,XT,i,h,r,flag,q)
rm(z,new_datapoint,df_x)

########################################################################

#####################

#####################

########################################################################Dec7 Test Data Proccessing 
df <- fread("C:\\Users\\rtlumb\\Documents\\Thesis_Fatigue\\Data_Analysis\\HighStress_LowCycle\\high_stress_dec7.txt",sep="auto",nrows=Inf, fill=TRUE)
specimen = 3;

q <- 1;
r <- 4;
flag <- 0;
df <- subset(df, df$PA0 < 4200 & df$PA0 > 100);
X <- c(1:length(unlist(df[,"PA0"])))
XT <- as.double(c(1:length(unlist(df[,"PA0"]))))
df <- cbind(df,X);
df <- cbind(df,XT);
for(i in 4:length(unlist(df[,"PA0"]))){
x <- df[i,"PA0"]- df[i-3,"PA0"];
r <- r+1;
flag <- flag +1;
if(!is.na(unlist(x))){
if(abs(unlist(x)) > 3000 & q == 1){
flag <- 0;
df[1:r,"X"] <- (q-1)*8000;
df[1:r,"XT"] <- (15*8000)-((q-1)*8000)
#df[1:r,"XT"] <- (q-1)/15;
assign(paste("df_",q,sep=""),df[1:r,]);
df_auto_seg(eval(as.symbol(paste("df_",q,sep=""))),q);
q <- q+1;
print("Once");}
else if (q > 1 & flag > 30 & abs(unlist(x)) > 2500){
h <- r - flag;
df[h:r,"X"] <- (q-1)*8000;
df[h:r,"XT"] <- (15*8000)-((q-1)*8000)
#df[h:r,"XT"] <- (q-1)/15;
assign(paste("df_",q,sep=""),df[h:r,]);
df_auto_seg(eval(as.symbol(paste("df_",q,sep=""))),q);
q <- q+1;
flag <- 0;
}
}}
q <- q-1
df_12 <- df_12[4:length(unlist(df_12[,"PA0"])),]

#############################Concate into NN input

for (z in 1:q){
df_x <- eval(as.symbol(paste("df_",z,sep="")))
for (i in 11:length(unlist(df_x[,"PA0"]))){
if(i == 11 & z == 1){
data <- cbind(Spec=specimen,ramp=z,df_x[i,"X"],df_x[i,"XT"],O=i-10,df_x[i,"E(SS)"],df_x[i,"RMS"],df_x[i-1,"PA0"],df_x[i-1,"E(SS)"],df_x[i-1,"RMS"],df_x[i-2,"PA0"],df_x[i-2,"E(SS)"],df_x[i-2,"RMS"],df_x[i-3,"PA0"],df_x[i-3,"E(SS)"],df_x[i-3,"RMS"],df_x[i-4,"PA0"],df_x[i-4,"E(SS)"],df_x[i-4,"RMS"],df_x[i-5,"PA0"],df_x[i-5,"E(SS)"],df_x[i-5,"RMS"],df_x[i-6,"PA0"],df_x[i-6,"E(SS)"],df_x[i-6,"RMS"],df_x[i-7,"PA0"],df_x[i-7,"E(SS)"],df_x[i-7,"RMS"],df_x[i-8,"PA0"],df_x[i-8,"E(SS)"],df_x[i-8,"RMS"],df_x[i-9,"PA0"],df_x[i-9,"E(SS)"],df_x[i-9,"RMS"],df_x[i-10,"PA0"],df_x[i-10,"E(SS)"],df_x[i-10,"RMS"])
}else{
new_datapoint <- NULL
new_datapoint <- cbind(Spec=specimen,ramp=z,df_x[i,"X"],df_x[i,"XT"],O=i-10,df_x[i,"E(SS)"],df_x[i,"RMS"],df_x[i-1,"PA0"],df_x[i-1,"E(SS)"],df_x[i-1,"RMS"],df_x[i-2,"PA0"],df_x[i-2,"E(SS)"],df_x[i-2,"RMS"],df_x[i-3,"PA0"],df_x[i-3,"E(SS)"],df_x[i-3,"RMS"],df_x[i-4,"PA0"],df_x[i-4,"E(SS)"],df_x[i-4,"RMS"],df_x[i-5,"PA0"],df_x[i-5,"E(SS)"],df_x[i-5,"RMS"],df_x[i-6,"PA0"],df_x[i-6,"E(SS)"],df_x[i-6,"RMS"],df_x[i-7,"PA0"],df_x[i-7,"E(SS)"],df_x[i-7,"RMS"],df_x[i-8,"PA0"],df_x[i-8,"E(SS)"],df_x[i-8,"RMS"],df_x[i-9,"PA0"],df_x[i-9,"E(SS)"],df_x[i-9,"RMS"],df_x[i-10,"PA0"],df_x[i-10,"E(SS)"],df_x[i-10,"RMS"])
data <- rbind(data, new_datapoint)
}
}}
trainData <- rbind(trainData,data)

################Clean Workspace
rm(df_1,df_2,df_3,df_4,df_5,df_6,df_7,df_8,df_9,df_10,df_11,df_12,df_13,df_14,df_15,df,data)
rm(x,X,XT,i,h,r,flag,q)
rm(z,new_datapoint,df_x,data)

########################################################################

#####################

#####################

########################################################################Dec13 Test Data Proccessing 
df <- fread("C:\\Users\\rtlumb\\Documents\\Thesis_Fatigue\\Data_Analysis\\HighStress_LowCycle\\high_stress_dec13.txt",sep="auto",nrows=Inf, fill=TRUE)
specimen = 4;

q <- 1;
r <- 4;
flag <- 0;
df <- subset(df, df$PA0 < 4200 & df$PA0 > 100);
X <- c(1:length(unlist(df[,"PA0"])))
XT <- as.double(c(1:length(unlist(df[,"PA0"]))))
df <- cbind(df,X);
df <- cbind(df,XT);
for(i in 4:length(unlist(df[,"PA0"]))){
x <- df[i,"PA0"]- df[i-3,"PA0"];
r <- r+1;
flag <- flag +1;
if(!is.na(unlist(x))){
if(abs(unlist(x)) > 3000 & q == 1){
flag <- 0;
df[1:r,"X"] <- (q-1)*8000;
df[1:r,"XT"] <- (12*8000)-((q-1)*8000)
#df[1:r,"XT"] <- (q-1)/12;
assign(paste("df_",q,sep=""),df[1:r,]);
df_auto_seg(eval(as.symbol(paste("df_",q,sep=""))),q);
q <- q+1;
print("Once");}
else if (q > 1 & flag > 30 & abs(unlist(x)) > 2500){
h <- r - flag;
df[h:r,"X"] <- (q-1)*8000;
df[h:r,"XT"] <- (12*8000)-((q-1)*8000)
#df[h:r,"XT"] <- (q-1)/12;
assign(paste("df_",q,sep=""),df[h:r,]);
df_auto_seg(eval(as.symbol(paste("df_",q,sep=""))),q);
q <- q+1;
flag <- 0;
}
}}
q <- q-1
df_3 <- df_3[53:length(unlist(df_3[,"PA0"])),]
df_9 <- df_9[2:length(unlist(df_9[,"PA0"])),]

#############################Concate into NN input

for (z in 1:q){
df_x <- eval(as.symbol(paste("df_",z,sep="")))
for (i in 11:length(unlist(df_x[,"PA0"]))){
if(i == 11 & z == 1){
data <- cbind(Spec=specimen,ramp=z,df_x[i,"X"],df_x[i,"XT"],O=i-10,df_x[i,"E(SS)"],df_x[i,"RMS"],df_x[i-1,"PA0"],df_x[i-1,"E(SS)"],df_x[i-1,"RMS"],df_x[i-2,"PA0"],df_x[i-2,"E(SS)"],df_x[i-2,"RMS"],df_x[i-3,"PA0"],df_x[i-3,"E(SS)"],df_x[i-3,"RMS"],df_x[i-4,"PA0"],df_x[i-4,"E(SS)"],df_x[i-4,"RMS"],df_x[i-5,"PA0"],df_x[i-5,"E(SS)"],df_x[i-5,"RMS"],df_x[i-6,"PA0"],df_x[i-6,"E(SS)"],df_x[i-6,"RMS"],df_x[i-7,"PA0"],df_x[i-7,"E(SS)"],df_x[i-7,"RMS"],df_x[i-8,"PA0"],df_x[i-8,"E(SS)"],df_x[i-8,"RMS"],df_x[i-9,"PA0"],df_x[i-9,"E(SS)"],df_x[i-9,"RMS"],df_x[i-10,"PA0"],df_x[i-10,"E(SS)"],df_x[i-10,"RMS"])
}else{
new_datapoint <- NULL
new_datapoint <- cbind(Spec=specimen,ramp=z,df_x[i,"X"],df_x[i,"XT"],O=i-10,df_x[i,"E(SS)"],df_x[i,"RMS"],df_x[i-1,"PA0"],df_x[i-1,"E(SS)"],df_x[i-1,"RMS"],df_x[i-2,"PA0"],df_x[i-2,"E(SS)"],df_x[i-2,"RMS"],df_x[i-3,"PA0"],df_x[i-3,"E(SS)"],df_x[i-3,"RMS"],df_x[i-4,"PA0"],df_x[i-4,"E(SS)"],df_x[i-4,"RMS"],df_x[i-5,"PA0"],df_x[i-5,"E(SS)"],df_x[i-5,"RMS"],df_x[i-6,"PA0"],df_x[i-6,"E(SS)"],df_x[i-6,"RMS"],df_x[i-7,"PA0"],df_x[i-7,"E(SS)"],df_x[i-7,"RMS"],df_x[i-8,"PA0"],df_x[i-8,"E(SS)"],df_x[i-8,"RMS"],df_x[i-9,"PA0"],df_x[i-9,"E(SS)"],df_x[i-9,"RMS"],df_x[i-10,"PA0"],df_x[i-10,"E(SS)"],df_x[i-10,"RMS"])
data <- rbind(data, new_datapoint)
}
}}
trainData <- rbind(trainData,data)

################Clean Workspace
rm(df_1,df_2,df_3,df_4,df_5,df_6,df_7,df_8,df_9,df_10,df_11,df_12,data)
rm(x,X,XT,i,h,r,flag,q)
rm(z,new_datapoint,df_x,data)

########################################################################

#####################

#####################

########################################################################Dec17 Test Data Proccessing 
df <- fread("C:\\Users\\rtlumb\\Documents\\Thesis_Fatigue\\Data_Analysis\\HighStress_LowCycle\\high_stress_dec17.txt",sep="auto",nrows=Inf, fill=TRUE)
specimen = 5;

q <- 1;
r <- 4;
flag <- 0;
df <- subset(df, df$PA0 < 4200 & df$PA0 > 100);
X <- c(1:length(unlist(df[,"PA0"])))
XT <- as.double(c(1:length(unlist(df[,"PA0"]))))
df <- cbind(df,X);
df <- cbind(df,XT);
for(i in 4:length(unlist(df[,"PA0"]))){
x <- df[i,"PA0"]- df[i-3,"PA0"];
r <- r+1;
flag <- flag +1;
if(!is.na(unlist(x))){
if(abs(unlist(x)) > 3000 & q == 1){
flag <- 0;
df[1:r,"X"] <- (q-1)*8000;
#df[1:r,"XT"] <- (q-1)/7;
df[1:r,"XT"] <- (7*8000)-((q-1)*8000)
assign(paste("df_",q,sep=""),df[1:r,]);
df_auto_seg(eval(as.symbol(paste("df_",q,sep=""))),q);
q <- q+1;
print("Once");}
else if (q > 1 & flag > 30 & abs(unlist(x)) > 2500){
h <- r - flag;
df[h:r,"X"] <- (q-1)*8000;
df[h:r,"XT"] <- (7*8000)-((q-1)*8000)
#df[h:r,"XT"] <- (q-1)/7;
assign(paste("df_",q,sep=""),df[h:r,]);
df_auto_seg(eval(as.symbol(paste("df_",q,sep=""))),q);
q <- q+1;
flag <- 0;
}
}}
q <- q-1

#############################Concate into NN input

for (z in 1:q){
df_x <- eval(as.symbol(paste("df_",z,sep="")))
for (i in 11:length(unlist(df_x[,"PA0"]))){
if(i == 11 & z == 1){
data <- cbind(Spec=specimen,ramp=z,df_x[i,"X"],df_x[i,"XT"],O=i-10,df_x[i,"E(SS)"],df_x[i,"RMS"],df_x[i-1,"PA0"],df_x[i-1,"E(SS)"],df_x[i-1,"RMS"],df_x[i-2,"PA0"],df_x[i-2,"E(SS)"],df_x[i-2,"RMS"],df_x[i-3,"PA0"],df_x[i-3,"E(SS)"],df_x[i-3,"RMS"],df_x[i-4,"PA0"],df_x[i-4,"E(SS)"],df_x[i-4,"RMS"],df_x[i-5,"PA0"],df_x[i-5,"E(SS)"],df_x[i-5,"RMS"],df_x[i-6,"PA0"],df_x[i-6,"E(SS)"],df_x[i-6,"RMS"],df_x[i-7,"PA0"],df_x[i-7,"E(SS)"],df_x[i-7,"RMS"],df_x[i-8,"PA0"],df_x[i-8,"E(SS)"],df_x[i-8,"RMS"],df_x[i-9,"PA0"],df_x[i-9,"E(SS)"],df_x[i-9,"RMS"],df_x[i-10,"PA0"],df_x[i-10,"E(SS)"],df_x[i-10,"RMS"])
}else{
new_datapoint <- NULL
new_datapoint <- cbind(Spec=specimen,ramp=z,df_x[i,"X"],df_x[i,"XT"],O=i-10,df_x[i,"E(SS)"],df_x[i,"RMS"],df_x[i-1,"PA0"],df_x[i-1,"E(SS)"],df_x[i-1,"RMS"],df_x[i-2,"PA0"],df_x[i-2,"E(SS)"],df_x[i-2,"RMS"],df_x[i-3,"PA0"],df_x[i-3,"E(SS)"],df_x[i-3,"RMS"],df_x[i-4,"PA0"],df_x[i-4,"E(SS)"],df_x[i-4,"RMS"],df_x[i-5,"PA0"],df_x[i-5,"E(SS)"],df_x[i-5,"RMS"],df_x[i-6,"PA0"],df_x[i-6,"E(SS)"],df_x[i-6,"RMS"],df_x[i-7,"PA0"],df_x[i-7,"E(SS)"],df_x[i-7,"RMS"],df_x[i-8,"PA0"],df_x[i-8,"E(SS)"],df_x[i-8,"RMS"],df_x[i-9,"PA0"],df_x[i-9,"E(SS)"],df_x[i-9,"RMS"],df_x[i-10,"PA0"],df_x[i-10,"E(SS)"],df_x[i-10,"RMS"])
data <- rbind(data, new_datapoint)
}
}}
trainData <- rbind(trainData,data)

################Clean Workspace
rm(df_1,df_2,df_3,df_4,df_5,df_6,df_7,data)
rm(x,X,XT,i,h,r,flag,q)
rm(z,new_datapoint,df_x,data)

########################################################################

#####################

#####################

########################################################################Jan3 Test Data Proccessing 
df <- fread("C:\\Users\\rtlumb\\Documents\\Thesis_Fatigue\\Data_Analysis\\HighStress_LowCycle\\high_stress_jan3.txt",sep="auto",nrows=Inf, fill=TRUE)
specimen = 6;

df <- subset(df, df$PA0 < 4200 & df$PA0 > 100);
part <- df[1:10350,];
df <- df[47195:length(unlist(df[,"PA0"])),];
df <- rbind(part,df);

q <- 1;
r <- 4;
flag <- 0;
df <- subset(df, df$PA0 < 4200 & df$PA0 > 100);
X <- c(1:length(unlist(df[,"PA0"])))
XT <- as.double(c(1:length(unlist(df[,"PA0"]))))
df <- cbind(df,X);
df <- cbind(df,XT);
for(i in 4:length(unlist(df[,"PA0"]))){
x <- df[i,"PA0"]- df[i-3,"PA0"];
r <- r+1;
flag <- flag +1;
if(!is.na(unlist(x))){
if(abs(unlist(x)) > 3000 & q == 1){
flag <- 0;
df[1:r,"X"] <- (q-1)*8000;
df[1:r,"XT"] <- (13*8000)-((q-1)*8000)
#df[1:r,"XT"] <- (q-1)/13;
assign(paste("df_",q,sep=""),df[1:r,]);
df_auto_seg(eval(as.symbol(paste("df_",q,sep=""))),q);
q <- q+1;
print("Once");}
else if (q > 1 & flag > 30 & abs(unlist(x)) > 2500){
h <- r - flag;
df[h:r,"X"] <- (q-1)*8000;
df[h:r,"XT"] <- (13*8000)-((q-1)*8000)
#df[h:r,"XT"] <- (q-1)/13;
assign(paste("df_",q,sep=""),df[h:r,]);
df_auto_seg(eval(as.symbol(paste("df_",q,sep=""))),q);
q <- q+1;
flag <- 0;
}
}}
q <- q-1

x <- df_3
df_3 <- df_2
x2 <- df_4
df_4 <- x
x <- df_5
df_5 <- x2
x2 <- df_6
df_6 <- x
x <- df_7
df_7 <- x2
x2 <- df_8
df_8 <- x
x <- df_9
df_9 <- x2
x2 <- df_10
df_10 <- x
x <- df_11
df_11 <- x2
x2 <- df_12
df_12 <- x
df_13 <- df_12
df_2 <- df[9698:9810,]


df_1 <- df_1[48:length(unlist(df_1[,"PA0"])),]
df_7 <- df_6[5:length(unlist(df_6[,"PA0"])),]
df_8 <- df_7[5:length(unlist(df_7[,"PA0"])),]
df_12 <- df_12[5:length(unlist(df_12[,"PA0"])),]
df_13 <- df_13[5:length(unlist(df_13[,"PA0"])),]

#############################Concate into NN input

for (z in 1:q){
df_x <- eval(as.symbol(paste("df_",z,sep="")))
for (i in 11:length(unlist(df_x[,"PA0"]))){
if(i == 11 & z == 1){
data <- cbind(Spec=specimen,ramp=z,df_x[i,"X"],df_x[i,"XT"],O=i-10,df_x[i,"E(SS)"],df_x[i,"RMS"],df_x[i-1,"PA0"],df_x[i-1,"E(SS)"],df_x[i-1,"RMS"],df_x[i-2,"PA0"],df_x[i-2,"E(SS)"],df_x[i-2,"RMS"],df_x[i-3,"PA0"],df_x[i-3,"E(SS)"],df_x[i-3,"RMS"],df_x[i-4,"PA0"],df_x[i-4,"E(SS)"],df_x[i-4,"RMS"],df_x[i-5,"PA0"],df_x[i-5,"E(SS)"],df_x[i-5,"RMS"],df_x[i-6,"PA0"],df_x[i-6,"E(SS)"],df_x[i-6,"RMS"],df_x[i-7,"PA0"],df_x[i-7,"E(SS)"],df_x[i-7,"RMS"],df_x[i-8,"PA0"],df_x[i-8,"E(SS)"],df_x[i-8,"RMS"],df_x[i-9,"PA0"],df_x[i-9,"E(SS)"],df_x[i-9,"RMS"],df_x[i-10,"PA0"],df_x[i-10,"E(SS)"],df_x[i-10,"RMS"])
}else{
new_datapoint <- NULL
new_datapoint <- cbind(Spec=specimen,ramp=z,df_x[i,"X"],df_x[i,"XT"],O=i-10,df_x[i,"E(SS)"],df_x[i,"RMS"],df_x[i-1,"PA0"],df_x[i-1,"E(SS)"],df_x[i-1,"RMS"],df_x[i-2,"PA0"],df_x[i-2,"E(SS)"],df_x[i-2,"RMS"],df_x[i-3,"PA0"],df_x[i-3,"E(SS)"],df_x[i-3,"RMS"],df_x[i-4,"PA0"],df_x[i-4,"E(SS)"],df_x[i-4,"RMS"],df_x[i-5,"PA0"],df_x[i-5,"E(SS)"],df_x[i-5,"RMS"],df_x[i-6,"PA0"],df_x[i-6,"E(SS)"],df_x[i-6,"RMS"],df_x[i-7,"PA0"],df_x[i-7,"E(SS)"],df_x[i-7,"RMS"],df_x[i-8,"PA0"],df_x[i-8,"E(SS)"],df_x[i-8,"RMS"],df_x[i-9,"PA0"],df_x[i-9,"E(SS)"],df_x[i-9,"RMS"],df_x[i-10,"PA0"],df_x[i-10,"E(SS)"],df_x[i-10,"RMS"])
data <- rbind(data, new_datapoint)
}
}}
trainData <- rbind(trainData,data)

################Clean Workspace
rm(df_1,df_2,df_3,df_4,df_5,df_6,df_7,df_8,df_9,df_10,df_11,df_12,df_13,df,data)
rm(x,X,XT,i,h,r,flag,q)
rm(z,new_datapoint,df_x,data)
rm(part,x2)

########################################################################

#####################

#####################

########################################################################Jan7 Test Data Proccessing 
df <- fread("C:\\Users\\rtlumb\\Documents\\Thesis_Fatigue\\Data_Analysis\\HighStress_LowCycle\\high_stress_jan7.txt",sep="auto",nrows=Inf, fill=TRUE)
specimen = 7;

q <- 1;
r <- 4;
flag <- 0;
df <- subset(df, df$PA0 < 4200 & df$PA0 > 100);
X <- c(1:length(unlist(df[,"PA0"])))
XT <- as.double(c(1:length(unlist(df[,"PA0"]))))
df <- cbind(df,X);
df <- cbind(df,XT);
for(i in 4:length(unlist(df[,"PA0"]))){
x <- df[i,"PA0"]- df[i-3,"PA0"];
r <- r+1;
flag <- flag +1;
if(!is.na(unlist(x))){
if(abs(unlist(x)) > 3000 & q == 1){
flag <- 0;
df[1:r,"X"] <- (q-1)*8000;
df[1:r,"XT"] <- (13*8000)-((q-1)*8000)
#df[1:r,"XT"] <- (q-1)/13;
assign(paste("df_",q,sep=""),df[1:r,]);
df_auto_seg(eval(as.symbol(paste("df_",q,sep=""))),q);
q <- q+1;
print("Once");}
else if (q > 1 & flag > 30 & abs(unlist(x)) > 2500){
h <- r - flag;
df[h:r,"X"] <- (q-1)*8000;
df[h:r,"XT"] <- (13*8000)-((q-1)*8000)
#df[h:r,"XT"] <- (q-1)/13;
assign(paste("df_",q,sep=""),df[h:r,]);
df_auto_seg(eval(as.symbol(paste("df_",q,sep=""))),q);
q <- q+1;
flag <- 0;
}
}}
q <- q-1


df_4 <- df_4[2:length(unlist(df_4[,"PA0"])),]
df_6 <- df_6[2:length(unlist(df_6[,"PA0"])),]

#############################Concate into NN input

for (z in 1:q){
df_x <- eval(as.symbol(paste("df_",z,sep="")))
for (i in 11:length(unlist(df_x[,"PA0"]))){
if(i == 11 & z == 1){
data <- cbind(Spec=specimen,ramp=z,df_x[i,"X"],df_x[i,"XT"],O=i-10,df_x[i,"E(SS)"],df_x[i,"RMS"],df_x[i-1,"PA0"],df_x[i-1,"E(SS)"],df_x[i-1,"RMS"],df_x[i-2,"PA0"],df_x[i-2,"E(SS)"],df_x[i-2,"RMS"],df_x[i-3,"PA0"],df_x[i-3,"E(SS)"],df_x[i-3,"RMS"],df_x[i-4,"PA0"],df_x[i-4,"E(SS)"],df_x[i-4,"RMS"],df_x[i-5,"PA0"],df_x[i-5,"E(SS)"],df_x[i-5,"RMS"],df_x[i-6,"PA0"],df_x[i-6,"E(SS)"],df_x[i-6,"RMS"],df_x[i-7,"PA0"],df_x[i-7,"E(SS)"],df_x[i-7,"RMS"],df_x[i-8,"PA0"],df_x[i-8,"E(SS)"],df_x[i-8,"RMS"],df_x[i-9,"PA0"],df_x[i-9,"E(SS)"],df_x[i-9,"RMS"],df_x[i-10,"PA0"],df_x[i-10,"E(SS)"],df_x[i-10,"RMS"])
}else{
new_datapoint <- NULL
new_datapoint <- cbind(Spec=specimen,ramp=z,df_x[i,"X"],df_x[i,"XT"],O=i-10,df_x[i,"E(SS)"],df_x[i,"RMS"],df_x[i-1,"PA0"],df_x[i-1,"E(SS)"],df_x[i-1,"RMS"],df_x[i-2,"PA0"],df_x[i-2,"E(SS)"],df_x[i-2,"RMS"],df_x[i-3,"PA0"],df_x[i-3,"E(SS)"],df_x[i-3,"RMS"],df_x[i-4,"PA0"],df_x[i-4,"E(SS)"],df_x[i-4,"RMS"],df_x[i-5,"PA0"],df_x[i-5,"E(SS)"],df_x[i-5,"RMS"],df_x[i-6,"PA0"],df_x[i-6,"E(SS)"],df_x[i-6,"RMS"],df_x[i-7,"PA0"],df_x[i-7,"E(SS)"],df_x[i-7,"RMS"],df_x[i-8,"PA0"],df_x[i-8,"E(SS)"],df_x[i-8,"RMS"],df_x[i-9,"PA0"],df_x[i-9,"E(SS)"],df_x[i-9,"RMS"],df_x[i-10,"PA0"],df_x[i-10,"E(SS)"],df_x[i-10,"RMS"])
data <- rbind(data, new_datapoint)
}
}}
trainData <- rbind(trainData,data)

################Clean Workspace
rm(df_1,df_2,df_3,df_4,df_5,df_6,df_7,df_8,df)
rm(x,X,XT,i,h,r,flag,q)
rm(z,new_datapoint,df_x,data)

########################################################################

#####################

#####################

########################################################################Jan8 Test Data Proccessing 
df <- fread("C:\\Users\\rtlumb\\Documents\\Thesis_Fatigue\\Data_Analysis\\HighStress_LowCycle\\high_stress_jan8.txt",sep="auto",nrows=Inf, fill=TRUE)
specimen = 8;

q <- 1;
r <- 4;
flag <- 0;
df <- subset(df, df$PA0 < 4200 & df$PA0 > 100);
X <- c(1:length(unlist(df[,"PA0"])))
XT <- as.double(c(1:length(unlist(df[,"PA0"]))))
df <- cbind(df,X);
df <- cbind(df,XT);
for(i in 4:length(unlist(df[,"PA0"]))){
x <- df[i,"PA0"]- df[i-3,"PA0"];
r <- r+1;
flag <- flag +1;
if(!is.na(unlist(x))){
if(abs(unlist(x)) > 3000 & q == 1){
flag <- 0;
df[1:r,"X"] <- (q-1)*8000;
df[1:r,"XT"] <- (13*8000)-((q-1)*8000)
#df[1:r,"XT"] <- (q-1)/13;
assign(paste("df_",q,sep=""),df[1:r,]);
df_auto_seg(eval(as.symbol(paste("df_",q,sep=""))),q);
q <- q+1;
print("Once");}
else if (q > 1 & flag > 30 & abs(unlist(x)) > 2500){
h <- r - flag;
df[h:r,"X"] <- (q-1)*8000;
df[h:r,"XT"] <- (13*8000)-((q-1)*8000)
#df[h:r,"XT"] <- (q-1)/13;
assign(paste("df_",q,sep=""),df[h:r,]);
df_auto_seg(eval(as.symbol(paste("df_",q,sep=""))),q);
q <- q+1;
flag <- 0;
}
}}
q <- q-1

df_2 <- df_2[134:length(unlist(df_2[,"PA0"])),]


df_3 <- df_3[1010:length(unlist(df_3[,"PA0"])),] 
df_4 <- df_4[1077:length(unlist(df_4[,"PA0"])),]
df_5 <- df_5[459:length(unlist(df_5[,"PA0"])),] 
df_6 <- df_6[550:length(unlist(df_6[,"PA0"])),]  
df_7 <- df_7[145:length(unlist(df_7[,"PA0"])),]  
df_8 <- df_8[112:length(unlist(df_8[,"PA0"])),] 




#############################Concate into NN input

for (z in 1:q){
df_x <- eval(as.symbol(paste("df_",z,sep="")))
for (i in 11:length(unlist(df_x[,"PA0"]))){
if(i == 11 & z == 1){
data <- cbind(Spec=specimen,ramp=z,df_x[i,"X"],df_x[i,"XT"],O=i-10,df_x[i,"E(SS)"],df_x[i,"RMS"],df_x[i-1,"PA0"],df_x[i-1,"E(SS)"],df_x[i-1,"RMS"],df_x[i-2,"PA0"],df_x[i-2,"E(SS)"],df_x[i-2,"RMS"],df_x[i-3,"PA0"],df_x[i-3,"E(SS)"],df_x[i-3,"RMS"],df_x[i-4,"PA0"],df_x[i-4,"E(SS)"],df_x[i-4,"RMS"],df_x[i-5,"PA0"],df_x[i-5,"E(SS)"],df_x[i-5,"RMS"],df_x[i-6,"PA0"],df_x[i-6,"E(SS)"],df_x[i-6,"RMS"],df_x[i-7,"PA0"],df_x[i-7,"E(SS)"],df_x[i-7,"RMS"],df_x[i-8,"PA0"],df_x[i-8,"E(SS)"],df_x[i-8,"RMS"],df_x[i-9,"PA0"],df_x[i-9,"E(SS)"],df_x[i-9,"RMS"],df_x[i-10,"PA0"],df_x[i-10,"E(SS)"],df_x[i-10,"RMS"])
}else{
new_datapoint <- NULL
new_datapoint <- cbind(Spec=specimen,ramp=z,df_x[i,"X"],df_x[i,"XT"],O=i-10,df_x[i,"E(SS)"],df_x[i,"RMS"],df_x[i-1,"PA0"],df_x[i-1,"E(SS)"],df_x[i-1,"RMS"],df_x[i-2,"PA0"],df_x[i-2,"E(SS)"],df_x[i-2,"RMS"],df_x[i-3,"PA0"],df_x[i-3,"E(SS)"],df_x[i-3,"RMS"],df_x[i-4,"PA0"],df_x[i-4,"E(SS)"],df_x[i-4,"RMS"],df_x[i-5,"PA0"],df_x[i-5,"E(SS)"],df_x[i-5,"RMS"],df_x[i-6,"PA0"],df_x[i-6,"E(SS)"],df_x[i-6,"RMS"],df_x[i-7,"PA0"],df_x[i-7,"E(SS)"],df_x[i-7,"RMS"],df_x[i-8,"PA0"],df_x[i-8,"E(SS)"],df_x[i-8,"RMS"],df_x[i-9,"PA0"],df_x[i-9,"E(SS)"],df_x[i-9,"RMS"],df_x[i-10,"PA0"],df_x[i-10,"E(SS)"],df_x[i-10,"RMS"])
data <- rbind(data, new_datapoint)
}
}}
trainData <- rbind(trainData,data)


################Clean Workspace
rm(df_1,df_2,df_3,df_4,df_5,df_6,df_7,df_8,df)
rm(x,X,XT,i,h,r,flag,q)
rm(z,new_datapoint,df_x,data)

########################################################################

#####################

#####################

########################################################################Jan10 Test Data Proccessing 
df <- fread("C:\\Users\\rtlumb\\Documents\\Thesis_Fatigue\\Data_Analysis\\HighStress_LowCycle\\high_stress_jan10.txt",sep="auto",nrows=Inf, fill=TRUE)
specimen = 9;

q <- 1;
r <- 4;
flag <- 0;
df <- subset(df, df$PA0 < 4200 & df$PA0 > 100);
X <- c(1:length(unlist(df[,"PA0"])))
XT <- as.double(c(1:length(unlist(df[,"PA0"]))))
df <- cbind(df,X);
df <- cbind(df,XT);
for(i in 4:length(unlist(df[,"PA0"]))){
x <- df[i,"PA0"]- df[i-3,"PA0"];
r <- r+1;
flag <- flag +1;
if(!is.na(unlist(x))){
if(abs(unlist(x)) > 3000 & q == 1){
flag <- 0;
df[1:r,"X"] <- (q-1)*8000;
df[1:r,"XT"] <- (13*8000)-((q-1)*8000)
#df[1:r,"XT"] <- (q-1)/13;
assign(paste("df_",q,sep=""),df[1:r,]);
df_auto_seg(eval(as.symbol(paste("df_",q,sep=""))),q);
q <- q+1;
print("Once");}
else if (q > 1 & flag > 30 & abs(unlist(x)) > 2500){
h <- r - flag;
df[h:r,"X"] <- (q-1)*8000;
df[h:r,"XT"] <- (13*8000)-((q-1)*8000)
#df[h:r,"XT"] <- (q-1)/13;
assign(paste("df_",q,sep=""),df[h:r,]);
df_auto_seg(eval(as.symbol(paste("df_",q,sep=""))),q);
q <- q+1;
flag <- 0;
}
}}
q <- q-1


df_7 <- df_7[2:length(unlist(df_7[,"PA0"])),]  
df_8 <- df_8[3:length(unlist(df_8[,"PA0"])),]
df_9 <- df_9[27:length(unlist(df_9[,"PA0"])),]
df_10 <- df_10[188:length(unlist(df_10[,"PA0"])),]


##################plot_df_plain(df_8 <- df_8[3:length(unlist(df_8[,"PA0"])),])##Plot TOOL 

#############################Concate into NN input

for (z in 1:q){
df_x <- eval(as.symbol(paste("df_",z,sep="")))
for (i in 11:length(unlist(df_x[,"PA0"]))){
if(i == 11 & z == 1){
data <- cbind(Spec=specimen,ramp=z,df_x[i,"X"],df_x[i,"XT"],O=i-10,df_x[i,"E(SS)"],df_x[i,"RMS"],df_x[i-1,"PA0"],df_x[i-1,"E(SS)"],df_x[i-1,"RMS"],df_x[i-2,"PA0"],df_x[i-2,"E(SS)"],df_x[i-2,"RMS"],df_x[i-3,"PA0"],df_x[i-3,"E(SS)"],df_x[i-3,"RMS"],df_x[i-4,"PA0"],df_x[i-4,"E(SS)"],df_x[i-4,"RMS"],df_x[i-5,"PA0"],df_x[i-5,"E(SS)"],df_x[i-5,"RMS"],df_x[i-6,"PA0"],df_x[i-6,"E(SS)"],df_x[i-6,"RMS"],df_x[i-7,"PA0"],df_x[i-7,"E(SS)"],df_x[i-7,"RMS"],df_x[i-8,"PA0"],df_x[i-8,"E(SS)"],df_x[i-8,"RMS"],df_x[i-9,"PA0"],df_x[i-9,"E(SS)"],df_x[i-9,"RMS"],df_x[i-10,"PA0"],df_x[i-10,"E(SS)"],df_x[i-10,"RMS"])
}else{
new_datapoint <- NULL
new_datapoint <- cbind(Spec=specimen,ramp=z,df_x[i,"X"],df_x[i,"XT"],O=i-10,df_x[i,"E(SS)"],df_x[i,"RMS"],df_x[i-1,"PA0"],df_x[i-1,"E(SS)"],df_x[i-1,"RMS"],df_x[i-2,"PA0"],df_x[i-2,"E(SS)"],df_x[i-2,"RMS"],df_x[i-3,"PA0"],df_x[i-3,"E(SS)"],df_x[i-3,"RMS"],df_x[i-4,"PA0"],df_x[i-4,"E(SS)"],df_x[i-4,"RMS"],df_x[i-5,"PA0"],df_x[i-5,"E(SS)"],df_x[i-5,"RMS"],df_x[i-6,"PA0"],df_x[i-6,"E(SS)"],df_x[i-6,"RMS"],df_x[i-7,"PA0"],df_x[i-7,"E(SS)"],df_x[i-7,"RMS"],df_x[i-8,"PA0"],df_x[i-8,"E(SS)"],df_x[i-8,"RMS"],df_x[i-9,"PA0"],df_x[i-9,"E(SS)"],df_x[i-9,"RMS"],df_x[i-10,"PA0"],df_x[i-10,"E(SS)"],df_x[i-10,"RMS"])
data <- rbind(data, new_datapoint)
}
}}
trainData <- rbind(trainData,data)


################Clean Workspace
rm(df_1,df_2,df_3,df_4,df_5,df_6,df_7,df_8,df_9,df_10,df)
rm(x,X,XT,i,h,r,flag,q)
rm(z,new_datapoint,df_x,data)



fileConn<-file("C:\\Users\\rtlum\\Documents\\DataSci_Projects\\PythonTensorFlowProjects\\Acoustic_Emission\\dataset.txt")
lines <- readLines(fileConn)
write.table(trainData,fileConn)
close(fileConn)