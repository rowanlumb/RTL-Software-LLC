library(shiny)
library(tidyverse)
library(shinydashboard)
library(rvest)
library(DT)
library(maps)
library(maptools)
library(rgdal)
library(rgeos)
library(sf)
library(leaflet)

#####################
####### F N S #######
#####################




get.html.data <- function(x){
  myurl <- read_html("https://www.tn.gov/health/cedep/ncov.html") # read our webpage as html
  myurl <- html_table(myurl)  # convert to an html table for ease of use
  
  return(myurl)
}


get.data <- function(x){

  tncounty_baseset <- st_read('TN_counties.shp')
  #counties <- as.list(levels(tncounty_baseset$NAME))
  counties <- tncounty_baseset$NAME
  counties <- paste(counties," County", sep="");
  
  myurl <- get.html.data();
  length <- length(unlist(myurl[[5]][1]))
  length <- length - 3
  covidCases <- myurl[[5]][1:length,]
  rm(newCol)

  test <- list.search(as.list(myurl[[5]]$County),. == "Stewart County")
  length(test)

  if(length(test) != 0){
  	for(g in 1:length(covidCases[,1])){
   		if("Stewart County" == covidCases[g,1]){
		  newCol <- c(newCol,covidCases[g,2]);
		}
	}
  }else{
	newCol <- 0;
  }

  for(i in 2:95){
	for(g in 1:length(covidCases[,1])){
   		if(counties[[i]][1] == covidCases[g,1]){
		  newCol <- c(newCol,covidCases[g,2]);
		}
	}
	if(i != length(newCol)){
	  newCol <- c(newCol,0);
	}
  }

  CASES <- newCol;
  tncounty_baseset <- cbind(tncounty_baseset,CASES);
  tncounty <- tncounty_baseset[,-(3:8)]
  tncounty <- tncounty[,-(4:15)]
   
  return(tncounty)
}
get.infobox.total_tests <- function(x){
  
  df1 <- get.data() # run the scraping function above and assign that data.frame to a variable
  df1 <- df1[1,6]  # assign the first value of the % gain column to same variable
  return(df1)   # return value
  
}
get.infobox.total_positives <- function(x){
  
  df <- get.data()  # run the scraping function above and assign that data.frame to a variable
  df <- df$Name[1]  # assign the first value of the name column to same variable
  return(df)   # return value
  
}
#####################
####### U I #########
#####################
ui <- dashboardPage(
  
  
  # H E A D E R
  
  dashboardHeader(title = "TN Coronavirus Map"),
  
  # S I D E B A R
  
  dashboardSidebar(
    
    h5("A reactive dashboard that pulls the lastest TN corona virus information from tn.gov. Refreshes every hour."),
    
    br(),
    br(),
    br(),
    br(),
    br(),
    br(),
    br(),
    br(),
    br(),
    br(),
    
    h6("Built by Rowan Thomas Lumb in the R computing language 
      "),
    br(),
    h6("R version 3.5.1 (2020-03-24)"),
    br(),
    a("rtldatasci@gmail.com", href="rtldatasci@gmail.com")
    
  ),
  
  # B O D Y
  dashboardBody(
  
  tags$style(type = "text/css", "#CoronaMap {height: calc(100vh - 75px) !important;}"),
  leafletOutput("CoronaMap")
  
 
    

  )
)


#####################
#### S E R V E R ####
#####################
server <- function(input, output) {
# R E A C T I V E 
  liveish_data <- reactive({
    return(get.data());
    invalidateLater(60000)    # refresh the report every 60k milliseconds (6000 seconds)
                  
  })
  
  
  # P L O T   O U T P U T
  output$CoronaMap <- renderLeaflet({
    tncounty <- liveish_data();
    high <- which.max(tncounty$CASES);
    high <- tncounty$CASES[high];
    interval <- high/20;
    leaflet(height = "100%");
    mapview(tncounty, zcol="CASES",col.regions=rev(heat.colors(20)),map.types = "CartoDB.Positron",at = seq(0, high, interval))@map
  })
 
  
  
  # I N F O B O X   O U T P U T - V A L
  output$top.coin <- renderInfoBox({
    infoBox(
      "Total Tested",
      paste0(live.infobox.val(), "%"),
      icon = icon("signal"),
      color = "purple",
      fill = TRUE)
  })
   
  
  # I N F O B O X   O U T P U T - N A M E
  output$top.name <- renderInfoBox({
    infoBox(
      "Total Tested Postive",
      live.infobox.coin(),
      icon = icon("bitcoin"),
      color = "purple",
      fill = TRUE)
  })
  
}
#####################
#### D E P L O Y ####
#####################
# Return a Shiny app objectshinyApp(ui = ui, server = server)
shinyApp(ui = ui, server = server)

