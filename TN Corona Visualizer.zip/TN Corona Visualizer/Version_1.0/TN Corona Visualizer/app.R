library(shiny)
library(shinydashboard)
library(rvest)
library(DT)
library(maps)
library(maptools)
library(rgdal)
library(rgeos)
library(sf)
library(leaflet)
library(rlist)
library(mapview)
library(rsconnect)

#####################
####### CoronaMap #######
#####################




get.html.data <- function(x){
  myurl <- read_html("https://www.tn.gov/health/cedep/ncov.html") # read our webpage as html
  myurl <- html_table(myurl)  # convert to an html table for ease of use
  
  return(myurl)
}


get.data <- function(x){

  tncounty_baseset <- st_read('TN_counties.shp')
  #counties <- as.list(levels(tncounty_baseset$NAME))
  counties <- tncounty_baseset$NAME
  counties <- paste(counties," County", sep="");
  
  myurl <- get.html.data();
  length <- length(unlist(myurl[[6]][1]))
  length <- length - 3
  covidCases <- myurl[[6]][1:length,]
  rm(newCol, newCol2);

  test <- list.search(as.list(covidCases[,1]),. == "Stewart")
  length(test)

  if(length(test) != 0){
  	for(g in 1:length(covidCases[,1])){
   		if("Stewart" == covidCases[g,1]){
		  newCol <- as.numeric(covidCases[g,2]);
		  newCol2 <- as.numeric(covidCases[g,3]);
		  break;
		}
	}
  }else{
	newCol <- 0;
	newCol2 <- 0;
  }

  for(i in 2:95){
	for(g in 1:length(covidCases[,1])){
   		if(counties[[i]][1] == covidCases[g,1]){
		  newCol <- c(newCol,as.numeric(covidCases[g,2]));
		  newCol2 <- c(newCol2,as.numeric(covidCases[g,3]));
		}
	}
	if(i != length(newCol)){
	  newCol <- c(newCol,0);
	}
  }

  CASES <- newCol;
  tncounty_baseset <- cbind(tncounty_baseset,CASES);
  tncounty <- tncounty_baseset[,-(3:8)]
  tncounty <- tncounty[,-(4:15)]
   
  return(tncounty)
}

#####################
####### U I #########
#####################
ui <- dashboardPage(

   
  
  
  # H E A D E R
  
  dashboardHeader(title = "TN Coronavirus Map"),
  
  # S I D E B A R
  
  dashboardSidebar(
    
    h5("A reactive dashboard that pulls the lastest TN corona virus information from tn.gov. Refreshes every hour."),
    
    br(),
    br(),
    br(),
    br(),
    br(),
    br(),
    br(),
    br(),
    br(),
    br(),
    
    h6("Built by Rowan Thomas Lumb in the R computing language 
      "),
    br(),
    h6("R version 3.5.1 (2020-03-24)"),
    br(),
    a("rtldatasci@gmail.com")
    
  ),
  
  # B O D Y
  dashboardBody(
  
  
  tags$style(type = "text/css", "#CoronaMap {height: calc(100vh - 50px) !important;}
  
      
      .content {
        padding: 0;
      }
	  body{
		overflow-y: hidden;
	  }
	  div.content-wrapper {
		margin-bottom: 0;
	  }
	  #popup tr.coord td{
		background-color: rgb(100, 157, 182);
	  }
	  .skin-blue .main-header .navbar{
		background-color: rgb(52, 101, 127);
	  }
	  .skin-blue .main-header .logo{
		background-color: rgb(52, 101, 127);
	  }
	 td, th{
		padding: .5%;
		padding-color: black;
	 }
	 .leaflet-popup-content-wrapper, .leaflet-popup-tip {
		background-color: rgb(100, 157, 182);
	 }
	 div.scrollableContainer{
		overflow-x: hidden;
	 }

    "),
  leafletOutput("CoronaMap")
  
 
    

  )
)


#####################
#### S E R V E R ####
#####################
server <- function(input, output) {
# R E A C T I V E 
  liveish_data <- reactive({
    return(get.data());
    invalidateLater(60000)    # refresh the report every 60k milliseconds (6000 seconds)
                  
  })
  
  
  # P L O T   O U T P U T
  output$CoronaMap <- renderLeaflet({
    TN <- liveish_data();
    high <- which.max(TN$CASES);
    high <- TN$CASES[high];
    interval <- high/20;
    leaflet(height = "100%");
    m <- mapview(TN, zcol="CASES",col.regions=rev(heat.colors(20)),map.types = "CartoDB.Positron",at = seq(0, high, interval))@map

  })

  
}
#####################
#### D E P L O Y ####
#####################
# Return a Shiny app objectshinyApp(ui = ui, server = server)
shinyApp(ui = ui, server = server)

