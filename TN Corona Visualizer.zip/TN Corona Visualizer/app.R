library(shiny)
library(tidyverse)
library(shinydashboard)
library(rvest)
library(DT)
library(maps)
library(maptools)
library(rgdal)
library(rgeos)
library(sf)
library(leaflet)
library(rlist)
library(taRifx)
library(mapview)
#####################
####### F N S #######
#####################




get.html.data <- function(x){
  myurl <- read_table("https://github.com/nytimes/covid-19-data/raw/master/us-counties.csv") # read our webpage as html
  #myurl <- html_table(myurl)  # convert to an html table for ease of use
  end <- length(myurl[[1]])
  myurl <- myurl[[1]][end-3143:end]
  myurl <- head(myurl,3143)

  for(i in 1:3143){

	  if(i == 1){
		covid_table <- unlist(strsplit(myurl[[1]], ","))
        #covid_table2 <- unlist(strsplit(myurl[[2]], ","))
        covid_table <- data.frame(t(unlist(covid_table)))
        colnames(covid_table) <- c("date","county","state","fips","cases","deaths");

	  }else{
		appender <- unlist(strsplit(myurl[[i]], ","))
        appender <- data.frame(t(unlist(appender)))
        colnames(appender) <- c("date","county","state","fips","cases","deaths");
        covid_table <- rbind(covid_table,appender);
	  }
  }

  myurl <- subset(covid_table,state=="Tennessee")
  myurl <- remove.factors(myurl)
  
  return(myurl)
}


get.data <- function(x){

  tncounty_baseset <- st_read('TN_counties.shp')
  #counties <- as.list(levels(tncounty_baseset$NAME))
  counties <- tncounty_baseset$NAME
  #counties <- paste(counties," County", sep="");
  
  myurl <- get.html.data();
  covidCases <- myurl
  #rm(newCol)

  #Artifact from testing the returned data
  #test <- list.search(as.list(myurl[2]$county),. == "Stewart")

  for(i in 1:95){
	for(g in 1:length(covidCases[,1])){
   		if(counties[[i]][1] == covidCases[g,2]){
		  if(i == 1){
			newCol <- as.numeric(covidCases[g,5]);
		  }else{
		    newCol <- c(newCol,as.numeric(covidCases[g,5]));
		  }
		}
	}
	if(i != length(newCol)){
	  newCol <- c(newCol,0);
	}
  }

  CASES <- newCol;
  tncounty_baseset <- cbind(tncounty_baseset,CASES);
  tncounty <- tncounty_baseset[,-(3:8)]
  tncounty <- tncounty[,-(4:15)]
   
  return(tncounty)
}
get.infobox.total_tests <- function(x){
  
  df1 <- get.data() # run the scraping function above and assign that data.frame to a variable
  df1 <- df1[1,6]  # assign the first value of the % gain column to same variable
  return(df1)   # return value
  
}
get.infobox.total_positives <- function(x){
  
  df <- get.data()  # run the scraping function above and assign that data.frame to a variable
  df <- df$Name[1]  # assign the first value of the name column to same variable
  return(df)   # return value
  
}
#####################
####### U I #########
#####################
ui <- dashboardPage(
  
  
  # H E A D E R
  
  dashboardHeader(title = "TN Coronavirus Map"),
  
  # S I D E B A R
  
  dashboardSidebar(
    
    h5("A reactive dashboard that pulls the latest TN corona virus information from the New York Times github page. Refreshes every hour."),
    
    br(),
    br(),
    br(),
    br(),
    br(),
    br(),
    br(),
    br(),
    br(),
    br(),
    
    h6("Built by Rowan Thomas Lumb in the R computing language 
      "),
    br(),
    h6("R version 3.5.1 (2020-03-24)"),
    br(),
    a("My Portfolio Page", href="https://rowanlumb.github.io/RTLDataSci/"),
    br(),
    a("Download the Project", href="https://github.com/rowanlumb/RTLDataSci/raw/master/TN%20Corona%20Visualizer.zip")
    
  ),
  
  # B O D Y
  dashboardBody(
  
  tags$style(type = "text/css", "#CoronaMap {height: calc(100vh - 75px) !important;}, #navbar {background-color: #34647f;}"),
  tags$head(
  tags$link(rel = "stylesheet", type = "text/css", href = "main.css")),
  leafletOutput("CoronaMap")
  
 
    

  )
)


#####################
#### S E R V E R ####
#####################
server <- function(input, output) {
# R E A C T I V E 
  liveish_data <- reactive({
    return(get.data());
    invalidateLater(60000)    # refresh the report every 60k milliseconds (6000 seconds)
                  
  })
  
  
  # P L O T   O U T P U T
  output$CoronaMap <- renderLeaflet({
    Tennessee <- liveish_data();
    high <- max(as.numeric(Tennessee$CASES));
    high <- high+100;
    interval <- as.integer(high/10);
    leaflet(height = "100%");
    mapview(Tennessee, zcol="CASES",at = seq(0, high, interval),col.regions=rev(heat.colors(10)),map.types = "CartoDB.Positron",legend=TRUE)@map
  })
 

  
}
#####################
#### D E P L O Y ####
#####################
# Return a Shiny app objectshinyApp(ui = ui, server = server)
shinyApp(ui = ui, server = server)

